#!/usr/bin/env python

from __future__ import print_function

import roslib
roslib.load_manifest('solution')
import sys
import rospy
import cv2
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import numpy as np 
import copy

class image_converter:
  
  def __init__(self):
    self.image_pub = rospy.Publisher("image_topic_2",Image, queue_size=10)
    self.light_pub = rospy.Publisher("/light", String, queue_size=10)

    self.bridge = CvBridge()
    self.image_sub = rospy.Subscriber("/video_source/raw",Image,self.callback)

    
    self.initTrackbars()
    self.hsvVals = {'hmin': 0, 'smin': 155, 'vmin': 126, 'hmax': 9, 'smax': 255, 'vmax': 255}
    self.cv_image = np.zeros((240,240,3), np.uint8)
    self.c=(255, 0, 0)
    self.conFound = []

  def empty(self, a):
        pass

  def initTrackbars(self):
        """
        To intialize Trackbars . Need to run only once
        """
        cv2.namedWindow("TrackBars")
        cv2.resizeWindow("TrackBars", 240, 240)
        cv2.createTrackbar("Hue Min", "TrackBars", 0, 179, self.empty)
        cv2.createTrackbar("Hue Max", "TrackBars", 179, 179, self.empty)
        cv2.createTrackbar("Sat Min", "TrackBars", 0, 255, self.empty)
        cv2.createTrackbar("Sat Max", "TrackBars", 255, 255, self.empty)
        cv2.createTrackbar("Val Min", "TrackBars", 0, 255, self.empty)
        cv2.createTrackbar("Val Max", "TrackBars", 255, 255, self.empty)

  def getTrackbarValues(self):
      """
      Gets the trackbar values in runtime
      :return: hsv values from the trackbar window
      """
      hmin = cv2.getTrackbarPos("Hue Min", "TrackBars")
      smin = cv2.getTrackbarPos("Sat Min", "TrackBars")
      vmin = cv2.getTrackbarPos("Val Min", "TrackBars")
      hmax = cv2.getTrackbarPos("Hue Max", "TrackBars")
      smax = cv2.getTrackbarPos("Sat Max", "TrackBars")
      vmax = cv2.getTrackbarPos("Val Max", "TrackBars")

      hsvVals = {"hmin": hmin, "smin": smin, "vmin": vmin,
                  "hmax": hmax, "smax": smax, "vmax": vmax}
      #print(hsvVals)
      return hsvVals

  def update(self, img, myColor=None):
      """
      :param img: Image in which color needs to be found
      :param hsvVals: List of lower and upper hsv range
      :return: (mask) bw image with white regions where color is detected
                (imgColor) colored image only showing regions detected
      """
      imgColor = [],
      mask = []
      myColor = self.getTrackbarValues()

      imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
      lower = np.array([myColor['hmin'], myColor['smin'], myColor['vmin']])
      upper = np.array([myColor['hmax'], myColor['smax'], myColor['vmax']])
      mask = cv2.inRange(imgHSV, lower, upper)
      imgColor = cv2.bitwise_and(img, img, mask=mask)

      return imgColor, mask

  
  def getColorHSV(self, myColor):

      if myColor == 'red':
          output = {'hmin': 146, 'smin': 141, 'vmin': 77, 'hmax': 179, 'smax': 255, 'vmax': 255}
      elif myColor == 'green':
          output = {'hmin': 44, 'smin': 79, 'vmin': 111, 'hmax': 79, 'smax': 255, 'vmax': 255}
      elif myColor == 'blue':
          output = {'hmin': 103, 'smin': 68, 'vmin': 130, 'hmax': 128, 'smax': 255, 'vmax': 255}
      else:
          output = None
          logging.warning("Color Not Defined")
          logging.warning("Available colors: red, green, blue ")

      return output
      
  #stop = {'hmin': 89, 'smin': 69, 'vmin': 110, 'hmax': 179, 'smax': 255, 'vmax': 185}
  #go = {'hmin': 160, 'smin': 71, 'vmin': 77, 'hmax': 128, 'smax': 255, 'vmax': 255}

  def findContours(img, imgPre, minArea=1000, sort=True, filter=0, drawCon=True, c=(255, 0, 0)):
    """
    Finds Contours in an image
    :param img: Image on which we want to draw
    :param imgPre: Image on which we want to find contours
    :param minArea: Minimum Area to detect as valid contour
    :param sort: True will sort the contours by area (biggest first)
    :param filter: Filters based on the corner points e.g. 4 = Rectangle or square
    :param drawCon: draw contours boolean
    :return: Foudn contours with [contours, Area, BoundingBox, Center]
    """
    conFound = []
    imgContours = imgPre
    _, contours, _ = cv2.findContours(imgContours, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
  
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if (area > 1000):
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
            # print(len(approx))
            if len(approx) == filter or filter == 0:
                if drawCon: cv2.drawContours(imgContours, cnt, -1, c, 3)
                x, y, w, h = cv2.boundingRect(approx)
                cx, cy = x + (w // 2), y + (h // 2)
                cv2.rectangle(imgContours, (x, y), (x + w, y + h), c, 2)
                cv2.circle(imgContours, (x + (w // 2), y + (h // 2)), 5, c, cv2.FILLED)
                conFound.append({"cnt": cnt, "area": area, "bbox": [x, y, w, h], "center": [cx, cy]})

    if sort:
        conFound = sorted(conFound, key=lambda x: x["area"], reverse=True)

    return imgContours, conFound

  def callback(self,data):
    try:
      self.cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
      print(e)

  def show_img(self):
    
    hsv_cv_image, mask = self.update(self.cv_image, self.hsvVals)
    '''
    gray = mask
    gaussian = cv2.medianBlur(gray, 5)
    thresh = cv2.threshold(gaussian, 200, 260, cv2.THRESH_BINARY)[1]    
    contours,hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    
    if(len(contours) > 0):
      try: 
        cnt = contours[0]
        ellipse = cv2.fitEllipse(cnt)
        pos = (ellipse[0])
        Radius = (ellipse[1][1])
        self.cv_image = cv2.ellipse(self.cv_image,ellipse,(0,255,0),10)
        self.cv_image = cv2.circle(self.cv_image, pos, 5, (0,255,0), -1)
        print("dist : "+str(90/Radius*30))
      except:
        print("no elipse")

    conFound = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if (area > 1000):
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
            # print(len(approx))
            cv2.drawContours(self.cv_image, cnt, -1, (0,255,0), 3)
            x, y, w, h = cv2.boundingRect(approx)
            cx, cy = x + (w // 2), y + (h // 2)
            cv2.rectangle(self.cv_image, (x, y), (x + w, y + h), (0,255,0), 2)
            cv2.circle(self.cv_image, (x + (w // 2), y + (h // 2)), 5, (0,0,255), cv2.FILLED)
            conFound.append({"cnt": cnt, "area": area, "bbox": [x, y, w, h], "center": [cx, cy]})

'''


    #gray_img = cv2.cvtColor(hsv_cv_image, cv2.COLOR_HSV2RGB)
    #gray_img2 = cv2.cvtColor(gray_img, cv2.COLOR_RGB2GRAY)
    #resize = cv2.resize(self.cv_image,(0,0), fx = 0.3, fy = 0.3)
    resize2 = cv2.resize(hsv_cv_image,(0,0), fx = 0.3, fy = 0.3)
    #cv2.imshow("Image window", resize)
    cv2.imshow("Image window2", resize2)

    #cv2.imshow("Trackbar", hsv_cv_image)
    cv2.waitKey(3)

    try:
      self.image_pub.publish(self.bridge.cv2_to_imgmsg(self.cv_image, "bgr8"))
    except CvBridgeError as e:
      print(e)

def main():
  ic = image_converter()
  rospy.init_node('image_converter', anonymous=True)
  f = rospy.Rate(1/0.01)
  while not rospy.is_shutdown():
    ic.show_img()
    f.sleep()
  cv2.destroyAllWindows()
  print("Shutting down")

if __name__ == '__main__':
    main()
