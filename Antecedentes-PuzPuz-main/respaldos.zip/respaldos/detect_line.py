#!/usr/bin/env python
# Actividad: Detectar lineas de la pista
# SIN ROS!

import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import matplotlib.pyplot as plt

#Load image
path = r'/home/noemi/puzzlebot/vision/src/traffic_light/imgs/road.jpeg'
cv_image = cv2.imread(path) # Read img

# Convert img to grayscale
gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

# Reduce img size
print('Original Dimensions : ', gray.shape)
width = 500
height = 400
dim = (width, height)
resized = cv2.resize(gray, dim)
print('New Dimensions : ',resized.shape)

# Gaussian Blur
preImage = cv2.GaussianBlur(resized,(5,5),0)

# Kernel
kernel = np.ones((5,5), np.uint8)

# Erosion and dilation
img_erosion = cv2.erode(preImage, kernel, iterations=1)
img_dilation = cv2.dilate(img_erosion, kernel, iterations=1)

# Region of interest
W = 500
H = 100
cropped_image = img_dilation[300:400, 0:500]
print(cropped_image.shape)	

# Increase height
H2 = 3500
dim = (W, H2)
tall = cv2.resize(cropped_image, dim)
print('New tall Dimensions : ', tall.shape)

x = list(range(0,500))
dark = np.argmin(tall, axis=0)

sumaC = np.add.reduce(tall, axis=0)
linea = np.argmin(sumaC)

# creating a plot
pixel_plot = plt.figure()
# plot
plt.plot(x,dark)
plt.xlim([-10,W])
plt.ylim([-10,H2+100])

# Display img
#cv2.imshow('Pre-processed image', img_dilation)
# Display cropped image
cv2.imshow("cropped", cropped_image)
cv2.imshow("cropped", dark)
# show plot
plt.show(pixel_plot)
cv2.waitKey(0)
cv2.destroyAllWindows()

